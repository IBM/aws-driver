

class StackNotFoundError(Exception):
    pass
